import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Intervention, InterventionStatus } from '@/types';
import { useAuth } from './useAuth';

export const useInterventions = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const interventionsQuery = useQuery({
    queryKey: ['interventions'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('interventions')
        .select(`
          *,
          client:clients(*)
        `)
        .order('start_time', { ascending: true });

      if (error) throw error;
      return data as Intervention[];
    },
    enabled: !!user,
  });

  const createIntervention = useMutation({
    mutationFn: async (intervention: {
      title: string;
      start_time: string;
      end_time: string;
      status?: InterventionStatus;
      client_id?: string | null;
      price_estimated?: number | null;
      notes?: string | null;
    }) => {
      const { data, error } = await supabase
        .from('interventions')
        .insert({
          ...intervention,
          user_id: user!.id,
          status: intervention.status || 'planned',
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['interventions'] });
    },
  });

  const updateIntervention = useMutation({
    mutationFn: async ({ id, ...intervention }: Partial<Intervention> & { id: string }) => {
      const { data, error } = await supabase
        .from('interventions')
        .update(intervention)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['interventions'] });
    },
  });

  const deleteIntervention = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('interventions')
        .delete()
        .eq('id', id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['interventions'] });
    },
  });

  return {
    interventions: interventionsQuery.data ?? [],
    isLoading: interventionsQuery.isLoading,
    error: interventionsQuery.error,
    createIntervention,
    updateIntervention,
    deleteIntervention,
  };
};
