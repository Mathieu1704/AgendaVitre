export type InterventionStatus = 'planned' | 'in_progress' | 'done';

export interface Client {
  id: string;
  name: string;
  address: string | null;
  phone: string | null;
  email: string | null;
  notes: string | null;
  user_id: string;
  created_at: string;
  updated_at: string;
}

export interface Intervention {
  id: string;
  title: string;
  start_time: string;
  end_time: string;
  status: InterventionStatus;
  client_id: string | null;
  price_estimated: number | null;
  notes: string | null;
  user_id: string;
  created_at: string;
  updated_at: string;
  client?: Client;
}

export interface CalendarEvent {
  id: string;
  title: string;
  start: Date;
  end: Date;
  backgroundColor: string;
  borderColor: string;
  extendedProps: {
    status: InterventionStatus;
    clientId: string | null;
    priceEstimated: number | null;
    notes: string | null;
  };
}
