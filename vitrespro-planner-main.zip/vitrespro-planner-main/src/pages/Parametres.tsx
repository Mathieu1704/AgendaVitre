import { useState } from 'react';
import { motion } from 'framer-motion';
import { User, Building2, Bell, Shield, Palette, Save, Loader2 } from 'lucide-react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { MotionCard, MotionCardContent, MotionCardHeader, MotionCardTitle, MotionCardDescription } from '@/components/ui/motion-card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { Avatar } from '@/components/Avatar';
import { useAuth } from '@/hooks/useAuth';
import { useTheme } from '@/hooks/useTheme';
import { toast } from 'sonner';

const Parametres = () => {
  const { user } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [loading, setLoading] = useState(false);

  const [companyData, setCompanyData] = useState({
    name: 'VitresPro',
    address: '',
    phone: '',
    email: user?.email || '',
    siret: '',
    tvaNumber: '',
  });

  const [notifications, setNotifications] = useState({
    emailReminders: true,
    newClient: true,
    interventionComplete: true,
    weeklyReport: false,
  });

  const handleSaveCompany = async () => {
    setLoading(true);
    // Simulate save
    await new Promise((resolve) => setTimeout(resolve, 1000));
    toast.success('Paramètres sauvegardés');
    setLoading(false);
  };

  return (
    <DashboardLayout>
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="space-y-6"
      >
        <div>
          <h1 className="text-2xl font-bold text-foreground">Paramètres</h1>
          <p className="text-muted-foreground">Gérez les paramètres de votre compte et de votre entreprise</p>
        </div>

        <Tabs defaultValue="profile" className="space-y-6">
          <TabsList className="bg-muted/50">
            <TabsTrigger value="profile" className="gap-2">
              <User className="h-4 w-4" />
              Profil
            </TabsTrigger>
            <TabsTrigger value="company" className="gap-2">
              <Building2 className="h-4 w-4" />
              Entreprise
            </TabsTrigger>
            <TabsTrigger value="notifications" className="gap-2">
              <Bell className="h-4 w-4" />
              Notifications
            </TabsTrigger>
            <TabsTrigger value="appearance" className="gap-2">
              <Palette className="h-4 w-4" />
              Apparence
            </TabsTrigger>
          </TabsList>

          {/* Profile Tab */}
          <TabsContent value="profile" className="space-y-6">
            <MotionCard>
              <MotionCardHeader>
                <MotionCardTitle>Informations du profil</MotionCardTitle>
                <MotionCardDescription>
                  Gérez vos informations personnelles
                </MotionCardDescription>
              </MotionCardHeader>
              <MotionCardContent className="space-y-6">
                <div className="flex items-center gap-6">
                  <Avatar name={user?.email || 'User'} size="lg" />
                  <div>
                    <p className="font-medium text-foreground">{user?.email}</p>
                    <p className="text-sm text-muted-foreground">Administrateur</p>
                  </div>
                </div>

                <Separator />

                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input id="email" value={user?.email || ''} disabled />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Téléphone</Label>
                    <Input id="phone" placeholder="Votre numéro de téléphone" />
                  </div>
                </div>

                <div className="flex justify-end">
                  <Button>
                    <Save className="mr-2 h-4 w-4" />
                    Sauvegarder
                  </Button>
                </div>
              </MotionCardContent>
            </MotionCard>

            <MotionCard>
              <MotionCardHeader>
                <MotionCardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5 text-primary" />
                  Sécurité
                </MotionCardTitle>
                <MotionCardDescription>
                  Gérez la sécurité de votre compte
                </MotionCardDescription>
              </MotionCardHeader>
              <MotionCardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Mot de passe</p>
                    <p className="text-sm text-muted-foreground">Dernière modification il y a 30 jours</p>
                  </div>
                  <Button variant="outline">Modifier</Button>
                </div>
              </MotionCardContent>
            </MotionCard>
          </TabsContent>

          {/* Company Tab */}
          <TabsContent value="company">
            <MotionCard>
              <MotionCardHeader>
                <MotionCardTitle>Informations de l'entreprise</MotionCardTitle>
                <MotionCardDescription>
                  Ces informations apparaîtront sur vos factures et devis
                </MotionCardDescription>
              </MotionCardHeader>
              <MotionCardContent className="space-y-6">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="companyName">Nom de l'entreprise</Label>
                    <Input
                      id="companyName"
                      value={companyData.name}
                      onChange={(e) => setCompanyData({ ...companyData, name: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="companyEmail">Email professionnel</Label>
                    <Input
                      id="companyEmail"
                      type="email"
                      value={companyData.email}
                      onChange={(e) => setCompanyData({ ...companyData, email: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="companyPhone">Téléphone</Label>
                    <Input
                      id="companyPhone"
                      value={companyData.phone}
                      onChange={(e) => setCompanyData({ ...companyData, phone: e.target.value })}
                      placeholder="01 23 45 67 89"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="siret">Numéro SIRET</Label>
                    <Input
                      id="siret"
                      value={companyData.siret}
                      onChange={(e) => setCompanyData({ ...companyData, siret: e.target.value })}
                      placeholder="123 456 789 00012"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="address">Adresse</Label>
                  <Textarea
                    id="address"
                    value={companyData.address}
                    onChange={(e) => setCompanyData({ ...companyData, address: e.target.value })}
                    placeholder="123 Rue de Paris&#10;75001 Paris"
                    rows={3}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="tva">Numéro de TVA intracommunautaire</Label>
                  <Input
                    id="tva"
                    value={companyData.tvaNumber}
                    onChange={(e) => setCompanyData({ ...companyData, tvaNumber: e.target.value })}
                    placeholder="FR 12 345678901"
                  />
                </div>

                <div className="flex justify-end">
                  <Button onClick={handleSaveCompany} disabled={loading}>
                    {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    <Save className="mr-2 h-4 w-4" />
                    Sauvegarder
                  </Button>
                </div>
              </MotionCardContent>
            </MotionCard>
          </TabsContent>

          {/* Notifications Tab */}
          <TabsContent value="notifications">
            <MotionCard>
              <MotionCardHeader>
                <MotionCardTitle>Préférences de notifications</MotionCardTitle>
                <MotionCardDescription>
                  Choisissez les notifications que vous souhaitez recevoir
                </MotionCardDescription>
              </MotionCardHeader>
              <MotionCardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Rappels par email</p>
                      <p className="text-sm text-muted-foreground">
                        Recevez un email de rappel avant chaque intervention
                      </p>
                    </div>
                    <Switch
                      checked={notifications.emailReminders}
                      onCheckedChange={(checked) =>
                        setNotifications({ ...notifications, emailReminders: checked })
                      }
                    />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Nouveau client</p>
                      <p className="text-sm text-muted-foreground">
                        Notification lors de l'ajout d'un nouveau client
                      </p>
                    </div>
                    <Switch
                      checked={notifications.newClient}
                      onCheckedChange={(checked) =>
                        setNotifications({ ...notifications, newClient: checked })
                      }
                    />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Intervention terminée</p>
                      <p className="text-sm text-muted-foreground">
                        Notification lorsqu'une intervention est marquée comme terminée
                      </p>
                    </div>
                    <Switch
                      checked={notifications.interventionComplete}
                      onCheckedChange={(checked) =>
                        setNotifications({ ...notifications, interventionComplete: checked })
                      }
                    />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Rapport hebdomadaire</p>
                      <p className="text-sm text-muted-foreground">
                        Recevez un résumé de votre activité chaque semaine
                      </p>
                    </div>
                    <Switch
                      checked={notifications.weeklyReport}
                      onCheckedChange={(checked) =>
                        setNotifications({ ...notifications, weeklyReport: checked })
                      }
                    />
                  </div>
                </div>
              </MotionCardContent>
            </MotionCard>
          </TabsContent>

          {/* Appearance Tab */}
          <TabsContent value="appearance">
            <MotionCard>
              <MotionCardHeader>
                <MotionCardTitle>Apparence</MotionCardTitle>
                <MotionCardDescription>
                  Personnalisez l'apparence de votre interface
                </MotionCardDescription>
              </MotionCardHeader>
              <MotionCardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Mode sombre</p>
                    <p className="text-sm text-muted-foreground">
                      Activez le mode sombre pour réduire la fatigue oculaire
                    </p>
                  </div>
                  <Switch checked={theme === 'dark'} onCheckedChange={toggleTheme} />
                </div>

                <Separator />

                <div className="space-y-4">
                  <p className="font-medium">Thème de couleur</p>
                  <div className="grid grid-cols-4 gap-3">
                    {[
                      { name: 'Bleu', color: 'bg-[#3B82F6]', active: true },
                      { name: 'Vert', color: 'bg-[#22C55E]', active: false },
                      { name: 'Violet', color: 'bg-[#8B5CF6]', active: false },
                      { name: 'Orange', color: 'bg-[#F97316]', active: false },
                    ].map((item) => (
                      <button
                        key={item.name}
                        className={`flex flex-col items-center gap-2 rounded-xl border-2 p-4 transition-colors ${
                          item.active ? 'border-primary' : 'border-transparent hover:border-border'
                        }`}
                      >
                        <div className={`h-8 w-8 rounded-full ${item.color}`} />
                        <span className="text-sm font-medium">{item.name}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </MotionCardContent>
            </MotionCard>
          </TabsContent>
        </Tabs>
      </motion.div>
    </DashboardLayout>
  );
};

export default Parametres;
