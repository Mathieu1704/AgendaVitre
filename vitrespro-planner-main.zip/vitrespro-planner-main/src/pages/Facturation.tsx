import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { FileText, Plus, Download, Euro, Calendar, CheckCircle2, Clock, Filter } from 'lucide-react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { MotionCard, MotionCardContent, MotionCardHeader, MotionCardTitle } from '@/components/ui/motion-card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { StatusBadge } from '@/components/StatusBadge';
import { Avatar } from '@/components/Avatar';
import { useInterventions } from '@/hooks/useInterventions';
import { Skeleton } from '@/components/ui/skeleton';
import { format, parseISO, startOfMonth, endOfMonth, isWithinInterval } from 'date-fns';
import { fr } from 'date-fns/locale';

const Facturation = () => {
  const { interventions, isLoading } = useInterventions();
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const completedInterventions = useMemo(() => {
    let filtered = interventions;
    if (statusFilter === 'done') {
      filtered = interventions.filter((i) => i.status === 'done');
    } else if (statusFilter === 'pending') {
      filtered = interventions.filter((i) => i.status !== 'done');
    }
    return filtered.filter((i) => i.price_estimated);
  }, [interventions, statusFilter]);

  const currentMonthStart = startOfMonth(new Date());
  const currentMonthEnd = endOfMonth(new Date());

  const stats = useMemo(() => {
    const thisMonth = interventions.filter((i) =>
      isWithinInterval(parseISO(i.start_time), { start: currentMonthStart, end: currentMonthEnd })
    );
    const completed = thisMonth.filter((i) => i.status === 'done');
    const pending = thisMonth.filter((i) => i.status !== 'done');

    return {
      totalRevenue: completed.reduce((acc, i) => acc + (i.price_estimated || 0), 0),
      pendingRevenue: pending.reduce((acc, i) => acc + (i.price_estimated || 0), 0),
      completedCount: completed.length,
      pendingCount: pending.length,
    };
  }, [interventions, currentMonthStart, currentMonthEnd]);

  return (
    <DashboardLayout>
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="space-y-6"
      >
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Facturation</h1>
            <p className="text-muted-foreground">Suivez vos revenus et générez des factures</p>
          </div>
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            Nouvelle facture
          </Button>
        </div>

        {/* Stats */}
        <div className="grid gap-4 md:grid-cols-4">
          <MotionCard>
            <MotionCardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="rounded-xl bg-status-done/10 p-3">
                  <Euro className="h-6 w-6 text-status-done" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Encaissé ce mois</p>
                  {isLoading ? (
                    <Skeleton className="h-7 w-24 mt-1" />
                  ) : (
                    <p className="text-2xl font-bold text-foreground">{stats.totalRevenue.toFixed(0)} €</p>
                  )}
                </div>
              </div>
            </MotionCardContent>
          </MotionCard>

          <MotionCard>
            <MotionCardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="rounded-xl bg-status-in-progress/10 p-3">
                  <Clock className="h-6 w-6 text-status-in-progress" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">En attente</p>
                  {isLoading ? (
                    <Skeleton className="h-7 w-24 mt-1" />
                  ) : (
                    <p className="text-2xl font-bold text-foreground">{stats.pendingRevenue.toFixed(0)} €</p>
                  )}
                </div>
              </div>
            </MotionCardContent>
          </MotionCard>

          <MotionCard>
            <MotionCardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="rounded-xl bg-status-done/10 p-3">
                  <CheckCircle2 className="h-6 w-6 text-status-done" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Interventions terminées</p>
                  {isLoading ? (
                    <Skeleton className="h-7 w-16 mt-1" />
                  ) : (
                    <p className="text-2xl font-bold text-foreground">{stats.completedCount}</p>
                  )}
                </div>
              </div>
            </MotionCardContent>
          </MotionCard>

          <MotionCard>
            <MotionCardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="rounded-xl bg-primary/10 p-3">
                  <Calendar className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Interventions planifiées</p>
                  {isLoading ? (
                    <Skeleton className="h-7 w-16 mt-1" />
                  ) : (
                    <p className="text-2xl font-bold text-foreground">{stats.pendingCount}</p>
                  )}
                </div>
              </div>
            </MotionCardContent>
          </MotionCard>
        </div>

        {/* Filter and table */}
        <MotionCard>
          <MotionCardHeader className="flex-row items-center justify-between space-y-0">
            <MotionCardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-primary" />
              Historique des interventions
            </MotionCardTitle>
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-muted-foreground" />
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Filtrer par statut" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Toutes</SelectItem>
                  <SelectItem value="done">Terminées</SelectItem>
                  <SelectItem value="pending">En attente</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </MotionCardHeader>
          <MotionCardContent>
            {isLoading ? (
              <div className="space-y-4">
                {[1, 2, 3, 4].map((i) => (
                  <Skeleton key={i} className="h-14 w-full" />
                ))}
              </div>
            ) : completedInterventions.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <div className="rounded-full bg-muted p-4 mb-4">
                  <FileText className="h-8 w-8 text-muted-foreground" />
                </div>
                <h3 className="font-medium text-foreground mb-1">Aucune intervention</h3>
                <p className="text-sm text-muted-foreground">
                  Les interventions avec un prix estimé apparaîtront ici
                </p>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Intervention</TableHead>
                    <TableHead className="hidden md:table-cell">Client</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Statut</TableHead>
                    <TableHead className="text-right">Montant</TableHead>
                    <TableHead className="w-[100px]">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {completedInterventions.map((intervention) => (
                    <TableRow key={intervention.id}>
                      <TableCell>
                        <p className="font-medium">{intervention.title}</p>
                      </TableCell>
                      <TableCell className="hidden md:table-cell">
                        {intervention.client ? (
                          <div className="flex items-center gap-2">
                            <Avatar name={intervention.client.name} size="sm" />
                            <span className="text-sm">{intervention.client.name}</span>
                          </div>
                        ) : (
                          <span className="text-muted-foreground text-sm">-</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <span className="text-sm text-muted-foreground">
                          {format(parseISO(intervention.start_time), 'dd MMM yyyy', { locale: fr })}
                        </span>
                      </TableCell>
                      <TableCell>
                        <StatusBadge status={intervention.status} />
                      </TableCell>
                      <TableCell className="text-right font-medium">
                        {intervention.price_estimated?.toFixed(2)} €
                      </TableCell>
                      <TableCell>
                        <Button variant="ghost" size="sm">
                          <Download className="h-4 w-4 mr-2" />
                          PDF
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </MotionCardContent>
        </MotionCard>
      </motion.div>
    </DashboardLayout>
  );
};

export default Facturation;
