import { motion } from 'framer-motion';
import { TrendingUp, Calendar, Users, Euro } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { MotionCard, MotionCardHeader, MotionCardTitle, MotionCardContent } from '@/components/ui/motion-card';
import { StatusBadge } from '@/components/StatusBadge';
import { Avatar } from '@/components/Avatar';
import { useInterventions } from '@/hooks/useInterventions';
import { useClients } from '@/hooks/useClients';
import { Skeleton } from '@/components/ui/skeleton';
import { format, isToday, parseISO } from 'date-fns';
import { fr } from 'date-fns/locale';

const chartData = [
  { name: 'Jan', interventions: 12 },
  { name: 'Fév', interventions: 19 },
  { name: 'Mar', interventions: 15 },
  { name: 'Avr', interventions: 25 },
  { name: 'Mai', interventions: 22 },
  { name: 'Juin', interventions: 30 },
];

const Dashboard = () => {
  const { interventions, isLoading: loadingInterventions } = useInterventions();
  const { clients, isLoading: loadingClients } = useClients();

  const todayInterventions = interventions.filter((i) => isToday(parseISO(i.start_time)));
  const upcomingInterventions = interventions.filter((i) => parseISO(i.start_time) >= new Date()).slice(0, 5);
  const totalRevenue = interventions.filter((i) => i.status === 'done').reduce((acc, i) => acc + (i.price_estimated || 0), 0);

  const stats = [
    { label: 'Chiffre d\'affaires', value: `${totalRevenue.toFixed(0)} €`, icon: Euro, color: 'text-status-done' },
    { label: 'Interventions à venir', value: upcomingInterventions.length.toString(), icon: Calendar, color: 'text-primary' },
    { label: 'Clients', value: clients.length.toString(), icon: Users, color: 'text-status-in-progress' },
  ];

  return (
    <DashboardLayout>
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="space-y-6"
      >
        <div>
          <h1 className="text-2xl font-bold text-foreground">Dashboard</h1>
          <p className="text-muted-foreground">Bienvenue sur votre tableau de bord VitresPro</p>
        </div>

        {/* Stats Cards */}
        <div className="grid gap-4 md:grid-cols-3">
          {stats.map((stat, index) => (
            <MotionCard key={stat.label} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.1 }}>
              <MotionCardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">{stat.label}</p>
                    {loadingInterventions || loadingClients ? (
                      <Skeleton className="h-8 w-20 mt-1" />
                    ) : (
                      <p className="text-3xl font-bold text-foreground">{stat.value}</p>
                    )}
                  </div>
                  <div className={`rounded-xl bg-muted p-3 ${stat.color}`}>
                    <stat.icon className="h-6 w-6" />
                  </div>
                </div>
              </MotionCardContent>
            </MotionCard>
          ))}
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          {/* Chart */}
          <MotionCard className="lg:col-span-2">
            <MotionCardHeader>
              <MotionCardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-primary" />
                Évolution des interventions
              </MotionCardTitle>
            </MotionCardHeader>
            <MotionCardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                    <XAxis dataKey="name" className="text-muted-foreground" tick={{ fill: 'hsl(var(--muted-foreground))' }} />
                    <YAxis className="text-muted-foreground" tick={{ fill: 'hsl(var(--muted-foreground))' }} />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--card))', 
                        border: '1px solid hsl(var(--border))', 
                        borderRadius: '0.5rem',
                        color: 'hsl(var(--foreground))'
                      }} 
                    />
                    <Area type="monotone" dataKey="interventions" stroke="hsl(217, 91%, 60%)" fill="hsl(217, 91%, 60%, 0.2)" strokeWidth={2} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </MotionCardContent>
          </MotionCard>

          {/* Today's Interventions */}
          <MotionCard>
            <MotionCardHeader>
              <MotionCardTitle>Aujourd'hui</MotionCardTitle>
            </MotionCardHeader>
            <MotionCardContent>
              {loadingInterventions ? (
                <div className="space-y-3">
                  {[1, 2, 3].map((i) => <Skeleton key={i} className="h-16 w-full" />)}
                </div>
              ) : todayInterventions.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-8">Aucune intervention aujourd'hui</p>
              ) : (
                <div className="space-y-3">
                  {todayInterventions.map((intervention) => (
                    <div key={intervention.id} className="flex items-center gap-3 rounded-xl bg-muted/50 p-3">
                      <Avatar name={intervention.client?.name || intervention.title} size="sm" />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{intervention.title}</p>
                        <p className="text-xs text-muted-foreground">
                          {format(parseISO(intervention.start_time), 'HH:mm', { locale: fr })}
                        </p>
                      </div>
                      <StatusBadge status={intervention.status} />
                    </div>
                  ))}
                </div>
              )}
            </MotionCardContent>
          </MotionCard>
        </div>
      </motion.div>
    </DashboardLayout>
  );
};

export default Dashboard;
