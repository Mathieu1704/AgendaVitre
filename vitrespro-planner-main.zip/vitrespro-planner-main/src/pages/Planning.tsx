import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import FullCalendar from '@fullcalendar/react';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import interactionPlugin from '@fullcalendar/interaction';
import listPlugin from '@fullcalendar/list';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { InterventionSheet } from '@/components/interventions/InterventionSheet';
import { InterventionDialog } from '@/components/interventions/InterventionDialog';
import { useInterventions } from '@/hooks/useInterventions';
import { Intervention } from '@/types';
import { Skeleton } from '@/components/ui/skeleton';
import { parseISO } from 'date-fns';


const statusColors = {
  planned: { bg: 'hsl(217, 91%, 60%)', border: 'hsl(217, 91%, 50%)' },
  in_progress: { bg: 'hsl(38, 92%, 50%)', border: 'hsl(38, 92%, 40%)' },
  done: { bg: 'hsl(142, 76%, 36%)', border: 'hsl(142, 76%, 26%)' },
};

const Planning = () => {
  const { interventions, isLoading } = useInterventions();
  const [sheetOpen, setSheetOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date>();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedIntervention, setSelectedIntervention] = useState<Intervention | null>(null);

  const calendarEvents = useMemo(() => {
    return interventions.map((intervention) => ({
      id: intervention.id,
      title: intervention.title,
      start: parseISO(intervention.start_time),
      end: parseISO(intervention.end_time),
      backgroundColor: statusColors[intervention.status].bg,
      borderColor: statusColors[intervention.status].border,
      extendedProps: {
        intervention,
      },
    }));
  }, [interventions]);

  const handleDateClick = (arg: { date: Date }) => {
    setSelectedDate(arg.date);
    setSheetOpen(true);
  };

  const handleEventClick = (arg: { event: { extendedProps: { intervention: Intervention } } }) => {
    setSelectedIntervention(arg.event.extendedProps.intervention);
    setDialogOpen(true);
  };

  return (
    <DashboardLayout>
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="space-y-6 h-full"
      >
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Planning</h1>
            <p className="text-muted-foreground">Gérez vos interventions au jour le jour</p>
          </div>
        </div>

        {isLoading ? (
          <div className="space-y-4">
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-[600px] w-full" />
          </div>
        ) : (
          <div className="bg-card rounded-2xl border border-border p-4 shadow-sm">
            <FullCalendar
              plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin, listPlugin]}
              initialView="dayGridMonth"
              locale="fr"
              headerToolbar={{
                left: 'prev,next today',
                center: 'title',
                right: 'dayGridMonth,timeGridWeek,timeGridDay,listWeek',
              }}
              buttonText={{
                today: "Aujourd'hui",
                month: 'Mois',
                week: 'Semaine',
                day: 'Jour',
                list: 'Agenda',
              }}
              events={calendarEvents}
              dateClick={handleDateClick}
              eventClick={handleEventClick}
              editable={false}
              selectable={true}
              height="auto"
              dayMaxEvents={3}
              nowIndicator={true}
              eventDisplay="block"
              eventClassNames="cursor-pointer"
            />
          </div>
        )}

        <InterventionSheet
          open={sheetOpen}
          onOpenChange={setSheetOpen}
          selectedDate={selectedDate}
        />

        <InterventionDialog
          intervention={selectedIntervention}
          open={dialogOpen}
          onOpenChange={setDialogOpen}
        />
      </motion.div>
    </DashboardLayout>
  );
};

export default Planning;
