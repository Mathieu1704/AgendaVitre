import { cn } from '@/lib/utils';

interface AvatarProps {
  name: string;
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

const getInitials = (name: string): string => {
  return name
    .split(' ')
    .map((word) => word.charAt(0))
    .join('')
    .toUpperCase()
    .slice(0, 2);
};

const getColorFromName = (name: string): string => {
  const colors = [
    'bg-primary',
    'bg-status-done',
    'bg-status-in-progress',
    'bg-chart-4',
    'bg-chart-5',
  ];
  const index = name.charCodeAt(0) % colors.length;
  return colors[index];
};

const sizeClasses = {
  sm: 'w-8 h-8 text-xs',
  md: 'w-10 h-10 text-sm',
  lg: 'w-12 h-12 text-base',
};

export const Avatar = ({ name, className, size = 'md' }: AvatarProps) => {
  const initials = getInitials(name);
  const bgColor = getColorFromName(name);

  return (
    <div
      className={cn(
        'flex items-center justify-center rounded-full font-medium text-primary-foreground',
        bgColor,
        sizeClasses[size],
        className
      )}
    >
      {initials}
    </div>
  );
};
