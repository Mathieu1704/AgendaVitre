import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { StatusBadge } from '@/components/StatusBadge';
import { useClients } from '@/hooks/useClients';
import { useInterventions } from '@/hooks/useInterventions';
import { Intervention, InterventionStatus } from '@/types';
import { toast } from 'sonner';
import { Loader2, MapPin, Phone, Euro, Clock, Trash2 } from 'lucide-react';
import { format, parseISO } from 'date-fns';
import { fr } from 'date-fns/locale';

interface InterventionDialogProps {
  intervention: Intervention | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const InterventionDialog = ({ intervention, open, onOpenChange }: InterventionDialogProps) => {
  const { clients } = useClients();
  const { updateIntervention, deleteIntervention } = useInterventions();
  const [loading, setLoading] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    title: intervention?.title || '',
    status: intervention?.status || 'planned',
    client_id: intervention?.client_id || '',
    price_estimated: intervention?.price_estimated?.toString() || '',
    notes: intervention?.notes || '',
  });

  const handleUpdate = async () => {
    if (!intervention) return;
    setLoading(true);
    
    try {
      await updateIntervention.mutateAsync({
        id: intervention.id,
        title: formData.title,
        status: formData.status as InterventionStatus,
        client_id: formData.client_id || null,
        price_estimated: formData.price_estimated ? parseFloat(formData.price_estimated) : null,
        notes: formData.notes || null,
      });
      toast.success('Intervention mise à jour');
      setIsEditing(false);
    } catch (error) {
      toast.error('Erreur lors de la mise à jour');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!intervention) return;
    setLoading(true);
    
    try {
      await deleteIntervention.mutateAsync(intervention.id);
      toast.success('Intervention supprimée');
      onOpenChange(false);
    } catch (error) {
      toast.error('Erreur lors de la suppression');
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = async (status: InterventionStatus) => {
    if (!intervention) return;
    try {
      await updateIntervention.mutateAsync({ id: intervention.id, status });
      toast.success('Statut mis à jour');
    } catch (error) {
      toast.error('Erreur lors de la mise à jour');
    }
  };

  if (!intervention) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <div className="flex items-start justify-between">
            <div>
              <DialogTitle className="text-xl">{intervention.title}</DialogTitle>
              <DialogDescription className="mt-1">
                {format(parseISO(intervention.start_time), "EEEE d MMMM yyyy", { locale: fr })}
              </DialogDescription>
            </div>
            <StatusBadge status={intervention.status} />
          </div>
        </DialogHeader>

        {isEditing ? (
          <div className="space-y-4 mt-4">
            <div className="space-y-2">
              <Label>Titre</Label>
              <Input
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label>Statut</Label>
              <Select value={formData.status} onValueChange={(value) => setFormData({ ...formData, status: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="planned">Planifiée</SelectItem>
                  <SelectItem value="in_progress">En cours</SelectItem>
                  <SelectItem value="done">Terminée</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Client</Label>
              <Select value={formData.client_id} onValueChange={(value) => setFormData({ ...formData, client_id: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Sélectionner" />
                </SelectTrigger>
                <SelectContent>
                  {clients.map((c) => (
                    <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Prix estimé (€)</Label>
              <Input
                type="number"
                value={formData.price_estimated}
                onChange={(e) => setFormData({ ...formData, price_estimated: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label>Notes</Label>
              <Textarea
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                rows={3}
              />
            </div>
            <div className="flex gap-2 pt-2">
              <Button variant="outline" onClick={() => setIsEditing(false)} className="flex-1">Annuler</Button>
              <Button onClick={handleUpdate} disabled={loading} className="flex-1">
                {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Sauvegarder
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-6 mt-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center gap-2 text-muted-foreground">
                <Clock className="h-4 w-4" />
                <span className="text-sm">
                  {format(parseISO(intervention.start_time), 'HH:mm')} - {format(parseISO(intervention.end_time), 'HH:mm')}
                </span>
              </div>
              {intervention.price_estimated && (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Euro className="h-4 w-4" />
                  <span className="text-sm">{intervention.price_estimated} €</span>
                </div>
              )}
            </div>

            {intervention.client && (
              <div className="rounded-xl border border-border p-4 space-y-2">
                <h4 className="font-medium">{intervention.client.name}</h4>
                {intervention.client.address && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <MapPin className="h-4 w-4" />
                    <span>{intervention.client.address}</span>
                  </div>
                )}
                {intervention.client.phone && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Phone className="h-4 w-4" />
                    <span>{intervention.client.phone}</span>
                  </div>
                )}
              </div>
            )}

            {intervention.notes && (
              <div className="rounded-xl bg-muted/50 p-4">
                <p className="text-sm text-muted-foreground">{intervention.notes}</p>
              </div>
            )}

            <div className="space-y-2">
              <Label className="text-sm text-muted-foreground">Changer le statut</Label>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant={intervention.status === 'planned' ? 'default' : 'outline'}
                  onClick={() => handleStatusChange('planned' as const)}
                  className="flex-1"
                >
                  Planifiée
                </Button>
                <Button
                  size="sm"
                  variant={intervention.status === 'in_progress' ? 'default' : 'outline'}
                  onClick={() => handleStatusChange('in_progress' as const)}
                  className="flex-1"
                >
                  En cours
                </Button>
                <Button
                  size="sm"
                  variant={intervention.status === 'done' ? 'default' : 'outline'}
                  onClick={() => handleStatusChange('done' as const)}
                  className="flex-1"
                >
                  Terminée
                </Button>
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <Button variant="destructive" size="sm" onClick={handleDelete} disabled={loading}>
                <Trash2 className="h-4 w-4 mr-2" />
                Supprimer
              </Button>
              <Button variant="outline" onClick={() => setIsEditing(true)} className="flex-1">
                Modifier
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};
