import { cn } from '@/lib/utils';
import { InterventionStatus } from '@/types';

interface StatusBadgeProps {
  status: InterventionStatus;
  className?: string;
}

const statusConfig: Record<InterventionStatus, { label: string; className: string }> = {
  planned: {
    label: 'Planifiée',
    className: 'bg-status-planned/10 text-status-planned border-status-planned/20',
  },
  in_progress: {
    label: 'En cours',
    className: 'bg-status-in-progress/10 text-status-in-progress border-status-in-progress/20',
  },
  done: {
    label: 'Terminée',
    className: 'bg-status-done/10 text-status-done border-status-done/20',
  },
};

export const StatusBadge = ({ status, className }: StatusBadgeProps) => {
  const config = statusConfig[status];

  return (
    <span
      className={cn(
        'inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium',
        config.className,
        className
      )}
    >
      {config.label}
    </span>
  );
};
